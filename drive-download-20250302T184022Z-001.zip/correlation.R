# Name : Muhammad Aiman Haiqal bin Salehuddin
# Matric No : B23CS0050

install.packages("ggplot2")
install.packages("gganimate")
install.packages("gifski")
install.packages("av")

library(readxl)
library(ggplot2)
library(gganimate)

data <- read_excel("C:/Users/User/Downloads/clean_lung_cancer.xlsx")

data <- na.omit(data[, c("Age", "Survival_Months")])

x <- data$Age
y <- data$Survival_Months

# calculate correlation
correlation_test <- cor.test(x, y)
print(correlation_test)

#Graph Plot for Correlation
p <- ggplot(data, aes(x = Age, y = Survival_Months)) +
  geom_point(color = "blue", size = 3) +
  geom_smooth(method = "lm", formula = y ~ x, col = "red") +
  labs(title = "Relationship between Age and Survival Months",
       x = "Age",
       y = "Survival Months") +
  theme_minimal()

print(p)