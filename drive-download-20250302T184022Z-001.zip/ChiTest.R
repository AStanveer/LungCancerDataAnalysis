library (readxl)

setwd ("~/Desktop")

MyData <- read_xlsx("clean_lung_cancer.xlsx")

MyData2 <- table (MyData$Gender, MyData$Tumor_Location)

MyData2

chisq.test(MyData2)