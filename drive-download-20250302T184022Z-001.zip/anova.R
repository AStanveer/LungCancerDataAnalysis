library(tidyverse)
library(readxl)

lung_cancer_data <- read_excel("lung_cancer_data.xlsx")


model <- aov(Survival_Months ~ Smoking_History, data = lung_cancer_data)
summary(model)
