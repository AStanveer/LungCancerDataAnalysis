library(dplyr)

library(readxl)


# data
clean_lung_cancer <- clean_lung_cancer %>%
  mutate(Smoking_Status = case_when(
    Smoking_History %in% c("Current Smoker", "Former Smoker") ~ "Smoker",
    Smoking_History == "Never Smoked" ~ "Non-Smoker"
  ))

# Calculate summary statistics
summary_stats <- clean_lung_cancer %>%
  group_by(Smoking_Status) %>%
  summarise(
    n = n(),
    mean= mean(Tumor_Size_mm),
    sd = sd(Tumor_Size_mm)
  )

print(summary_stats)

#t-test statistics

xbar1 = 54.5
xbar2 = 49.4

s1 = 24.3
s2 = 28.0

n1 = 43 # Non-Smoker
n2 = 58 # Smoker

t0 = (xbar1-xbar2-0)/(sqrt((s1^2/n1)+(s2^2/n2))) 

v = ((s1^2/n1)+(s2^2/n2))^2/((((s1^2/n1)^2)/(n1-1))+(((s2^2/n2)^2)/(n2-1)))

alpha = 0.05
t.alpha = qt(alpha/2, floor(v))

cat("Critical value: ",t.alpha,"\n")
cat("Degree of freedom: ",v,"\n")
cat("Test Statistic (t0): ", t0,"\n")


#Regression

x <- data$Age  #Independent variable
y <-data$Survival_Months  #dependent variable
n <- 100
sum(x)

sum(y)

sum(x^2)

sum(x*y)

b1 <-(sum(x*y)-(sum(x)*sum(y)/n))/(sum(x^2)-((sum(x)^2)/n))
cat("b1: ",b1,"\n")

mean(x)

mean(y)

b0 <- mean(y)-(b1*mean(x))
cat("b0: ",b0,"\n")

#bar plot

plot(x,y,main="Age against survival months",col="blue", xlab = "Age", ylab = "Survival months")

model <- lm(y~x)
abline(model)

#r^2

yhat <- b0+(b1*x)
ssr <- sum((yhat-mean(y))^2)
sst <- sum((y-mean(y))^2)
r2 <- ssr/sst
cat("r^2: ",r2,"\n")

